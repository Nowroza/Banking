From the CRUD concept, this app implements simple RU (Read & Update) from SQLite database

To display the list of contacts, RecyclerView is used

Demo link of the app: https://youtu.be/mOxQz7Kpmy8

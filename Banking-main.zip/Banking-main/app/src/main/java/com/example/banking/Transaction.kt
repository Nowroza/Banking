package com.example.banking

data class Transaction(
    val From: String,
    val To: String,
    val amt: Int
)